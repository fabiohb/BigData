package br.edu.uni7.mongoapp;

import java.util.function.Consumer;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Main {

	public static void main(String[] args) {
		try (MongoClient mongoClient = new MongoClient("localhost", 27017)) {
			mongoClient.listDatabaseNames().forEach(
				(Consumer<String>) System.out::println
			);

			
			MongoDatabase database = mongoClient.getDatabase("bigdata");
			MongoCollection<Document> gastos = database.getCollection("gastos");

			BasicDBObject filter = new BasicDBObject();
			filter.put("Valor", 100.0);

			gastos.find(filter)
				.limit(20)
				.forEach(
					(Consumer<Document>) System.out::println
				);
			
			
			gastos.insertOne(
				new Document()
					.append("name", "F�bio")
					.append("company", "Detran")
					.append("Valor", 123456)
			);
			
			gastos.find(
					new Document()
						.append("name", "F�bio")
				)
				.limit(20)
				.forEach(
					(Consumer<Document>) System.out::println
				);
		}
	}

}
